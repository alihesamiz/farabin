from apps.salesdata.repositories.sale_repo import *  # noqa: F403
